# Push PartyWise to GitHub - Quick Instructions

Your code is ready to push! Follow these steps:

## Option 1: Using GitHub Web Interface (Fastest)

1. Go to https://github.com/new
2. Repository name: `partywise`
3. Description: `AI-powered party planning platform - Hackathon Demo`
4. Make it **Public**
5. **DO NOT** initialize with README, .gitignore, or license
6. Click "Create repository"

7. Copy the commands GitHub shows you under "push an existing repository from the command line"

8. In your terminal, run:
```bash
cd /home/ubuntu/partywise
git remote add origin https://github.com/madampresident2040/partywise.git
git branch -M main
git push -u origin main
```

## Option 2: Download and Push Locally

1. Download all project files from Manus
2. On your local machine:
```bash
cd path/to/partywise
git init
git add .
git commit -m "Initial commit: PartyWise hackathon demo"
git remote add origin https://github.com/madampresident2040/partywise.git
git branch -M main
git push -u origin main
```

## Your Repository URL
Once pushed: `https://github.com/madampresident2040/partywise`

## Demo URL
Live demo: https://3000-ii1xs6df3c7td9sxi93dh-5a6092fd.manusvm.computer

---

## Project Features to Highlight in Demo

✅ **AI-Powered Vendor Search** - Compare venues, caterers, photographers by zipcode
✅ **Social Media Integration** - Discover Instagram/Facebook vendors (bakers, florists)
✅ **Guest Management** - Full RSVP tracking and email invites
✅ **Budget Tracker** - Visual progress bars, category breakdown, over-budget alerts
✅ **Planning Timeline** - 12 milestone checklist from 24 weeks to event day
✅ **Booking Calendar** - Track all vendor bookings and confirmations
✅ **Digital Ocean AI Chatbot** - Embedded party planning assistant
✅ **Amazon Integration** - Product search with best value/price ranking

Good luck with your hackathon! 🎉
