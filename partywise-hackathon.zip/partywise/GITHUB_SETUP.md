# Push PartyWise to GitHub - Simple Instructions

## Fastest Method: Manual Upload

Since GitHub CLI authentication is having issues, here's the quickest way:

### Step 1: Download Your Project
1. In Manus, go to the Code panel in Management UI
2. Click "Download All Files" button
3. Save the ZIP file and extract it on your computer

### Step 2: Create GitHub Repository
1. Go to https://github.com/new
2. Repository name: `partywise`
3. Description: `AI-powered party planning platform - Hackathon Demo`
4. Make it **Public**
5. **DO NOT** check any boxes (no README, no .gitignore, no license)
6. Click "Create repository"

### Step 3: Upload Files
**Option A: Using GitHub Web Interface (Easiest)**
1. On your new repository page, click "uploading an existing file"
2. Drag and drop ALL the extracted files
3. Commit message: "Initial commit: PartyWise hackathon demo"
4. Click "Commit changes"

**Option B: Using Git Command Line**
1. Open terminal in your extracted project folder
2. Run these commands:
```bash
git init
git add .
git commit -m "Initial commit: PartyWise hackathon demo"
git branch -M main
git remote add origin https://github.com/madampresident2040/partywise.git
git push -u origin main
```

## Your Repository URL
https://github.com/madampresident2040/partywise

## Live Demo URL
https://3000-ii1xs6df3c7td9sxi93dh-5a6092fd.manusvm.computer

---

## Key Features to Highlight in Your Demo

✨ **AI-Powered Vendor Search**
- Compare venues, caterers, photographers by zipcode
- Real-time AI recommendations with pricing

🌸 **Social Media Vendor Discovery**
- Find Instagram/Facebook vendors (bakers, florists)
- Side-by-side comparison tool

👥 **Guest List Management**
- Full RSVP tracking
- Email invite sending
- Dietary restrictions tracking

💰 **Budget Tracker**
- Visual progress bars
- Category breakdown
- Over-budget alerts

📅 **Planning Timeline**
- 12 AI-powered milestones
- Progress tracking

📆 **Booking Calendar**
- Vendor booking management
- Confirmation tracking

🤖 **Digital Ocean AI Chatbot**
- Embedded party planning assistant
- Custom pink/blue theme

---

## Demo Tips

1. **Start with the landing page** - Show off the playful design with party emojis
2. **Sign in** - Show the authentication flow
3. **Create an event** - Enter a zipcode (try 94102 or 10001)
4. **Search vendors** - Demonstrate AI recommendations
5. **Add guests** - Show RSVP tracking
6. **Check budget** - Display visual progress bars
7. **Use the chatbot** - Click the pink button in bottom-right corner

Good luck with your hackathon! 🎉
