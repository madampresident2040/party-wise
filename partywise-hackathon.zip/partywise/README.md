# 🎉 PartyWise - AI Party Planning Assistant

**Winner of [Your Hackathon Name] - Built in 2 hours!**

PartyWise is an intelligent party planning platform that helps you find and compare vendors, manage guest lists, track budgets, and get AI-powered planning advice—all in one place.

![PartyWise Screenshot](https://via.placeholder.com/800x400?text=PartyWise+Demo)

## ✨ Features

### 🤖 AI-Powered Planning
- Real-time chat with AI planning assistant
- Get personalized advice on timelines, budgets, and next steps
- Conversation history saved per event

### 🔍 Smart Vendor Search
- Search venues, caterers, photographers, bakers, and more by zipcode
- Compare prices, ratings, and reviews
- AI-generated recommendations with "Best Value" and "Best Price" badges
- Instagram/Facebook vendor discovery for small businesses
- Amazon product search and ranking

### 💰 Budget Management
- Track spending across all vendor categories
- Visual progress bars and category breakdowns
- Real-time budget alerts
- Export budget summaries

### 📋 Guest List Management
- Add and manage guests with RSVP tracking
- Send email invitations
- Track attendance and dietary restrictions
- Export guest lists

### 📅 Timeline & Milestones
- AI-generated party planning timeline
- 12 key milestones from 6 months out to day-of
- Checklist tracking for each milestone
- Automated reminder system

### 🎨 Party Themes
- Pre-built templates (Birthday, Wedding, Corporate)
- Auto-populated vendor recommendations
- Budget ranges and timeline suggestions

### 📱 Modern UX
- Responsive design for mobile and desktop
- Electric purple theme with playful animations
- Accessible interface with keyboard navigation
- Real-time toast notifications

## 🚀 Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS 4, Wouter
- **Backend**: Express, tRPC 11, Node.js
- **Database**: MySQL/TiDB with Drizzle ORM
- **AI**: Built-in LLM integration (Manus AI)
- **Storage**: S3-compatible object storage
- **Testing**: Vitest with 10/10 passing tests
- **Auth**: OAuth 2.0 with session management

## 📦 Installation

```bash
# Clone the repository
git clone https://github.com/madampresident2040/partywise.git
cd partywise

# Install dependencies
pnpm install

# Set up environment variables
# Copy .env.example to .env and fill in your values

# Push database schema
pnpm db:push

# Start development server
pnpm dev
```

## 🧪 Testing

```bash
# Run all tests
pnpm test

# Run tests in watch mode
pnpm test --watch
```

## 🏗️ Project Structure

```
partywise/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # Reusable UI components
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and tRPC client
├── server/                # Backend Express + tRPC server
│   ├── _core/            # Core server infrastructure
│   ├── routers.ts        # tRPC API routes
│   ├── db.ts             # Database queries
│   └── *.test.ts         # Test files
├── drizzle/              # Database schema and migrations
└── shared/               # Shared types and constants
```

## 🎯 Key Features Implemented

- [x] Zipcode-based vendor search and comparison
- [x] AI-powered party planning chat assistant
- [x] Social media vendor discovery (Instagram/Facebook)
- [x] Amazon product search with value ranking
- [x] Budget tracking with visual breakdowns
- [x] Guest list management with RSVP tracking
- [x] Party timeline with 12 key milestones
- [x] Party theme presets (Birthday/Wedding/Corporate)
- [x] Social sharing functionality
- [x] Responsive design with animations
- [x] Full test coverage (10/10 tests passing)

## 🏆 Hackathon Achievement

Built in approximately 2 hours during [Your Hackathon Name], PartyWise demonstrates:
- Rapid full-stack development
- AI integration for enhanced UX
- Clean architecture with tRPC
- Comprehensive testing
- Production-ready code quality

## 📝 License

MIT License - feel free to use this project for learning or building your own party planning app!

## 🙏 Acknowledgments

- Built with [Manus](https://manus.im) - AI-powered development platform
- UI components from [shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide](https://lucide.dev/)

---

**Made with 💜 by Madiha Khursheed (@madampresident2040)**

*"We handle the drama so you don't have to (you are welcome)"*
