import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Planner from "./pages/Planner";
import SocialVendors from "./pages/SocialVendors";
import Guests from "./pages/Guests";
import Budget from "./pages/Budget";
import Timeline from "./pages/Timeline";
import Booking from "./pages/Booking";
import Themes from "./pages/Themes";
import Navigation from "./components/Navigation";
import { useLocation } from "wouter";

function Router() {
  const [location] = useLocation();
  const showNav = location !== "/";

  return (
    <>
      {showNav && <Navigation />}
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/planner"} component={Planner} />
        <Route path={"/social-vendors"} component={SocialVendors} />
        <Route path={"/guests"} component={Guests} />
        <Route path={"/budget"} component={Budget} />
        <Route path={"/timeline"} component={Timeline} />
        <Route path={"/booking"} component={Booking} />
        <Route path={"/themes"} component={Themes} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
