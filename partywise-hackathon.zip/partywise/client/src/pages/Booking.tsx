import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CalendarDays, Clock, MapPin, Phone, Mail } from "lucide-react";
import { useLocation } from "wouter";

const mockBookings = [
  {
    id: 1,
    vendor: "Grand Ballroom",
    category: "Venue",
    date: "2024-06-15",
    time: "6:00 PM - 11:00 PM",
    status: "confirmed",
    contact: "venue@grandballroom.com",
    phone: "(555) 123-4567",
    location: "123 Main St, San Francisco, CA"
  },
  {
    id: 2,
    vendor: "Gourmet Catering Co",
    category: "Catering",
    date: "2024-06-15",
    time: "5:00 PM setup",
    status: "pending",
    contact: "info@gourmetcatering.com",
    phone: "(555) 234-5678",
    location: "Will travel to venue"
  },
  {
    id: 3,
    vendor: "Moments Photography",
    category: "Photography",
    date: "2024-06-15",
    time: "5:30 PM - 10:00 PM",
    status: "confirmed",
    contact: "bookings@momentsphotography.com",
    phone: "(555) 345-6789",
    location: "Will travel to venue"
  },
];

export default function Booking() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <CalendarDays className="w-12 h-12 mx-auto text-primary" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to manage your vendor bookings.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <CalendarDays className="w-8 h-8 text-primary" />
            Vendor Booking Calendar
          </h1>
          <p className="text-muted-foreground mt-1">
            Track all your vendor bookings and availability
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card className="p-4 border-green-200 bg-green-50">
            <div className="text-2xl font-bold text-green-700">
              {mockBookings.filter(b => b.status === "confirmed").length}
            </div>
            <div className="text-sm text-green-600">Confirmed</div>
          </Card>
          <Card className="p-4 border-yellow-200 bg-yellow-50">
            <div className="text-2xl font-bold text-yellow-700">
              {mockBookings.filter(b => b.status === "pending").length}
            </div>
            <div className="text-sm text-yellow-600">Pending</div>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold">{mockBookings.length}</div>
            <div className="text-sm text-muted-foreground">Total Bookings</div>
          </Card>
        </div>

        {/* Bookings List */}
        <div className="space-y-4">
          {mockBookings.map(booking => (
            <Card key={booking.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-semibold">{booking.vendor}</h3>
                    <Badge variant="outline">{booking.category}</Badge>
                    {booking.status === "confirmed" && (
                      <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                        Confirmed
                      </Badge>
                    )}
                    {booking.status === "pending" && (
                      <Badge variant="secondary">Pending</Badge>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <CalendarDays className="w-4 h-4" />
                    <span>{new Date(booking.date).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>{booking.time}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{booking.location}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    <a href={`mailto:${booking.contact}`} className="hover:text-primary">
                      {booking.contact}
                    </a>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <a href={`tel:${booking.phone}`} className="hover:text-primary">
                      {booking.phone}
                    </a>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                {booking.status === "pending" && (
                  <Button size="sm" variant="outline">
                    Confirm Booking
                  </Button>
                )}
                <Button size="sm" variant="outline">
                  Send Reminder
                </Button>
                <Button size="sm" variant="outline">
                  View Details
                  </Button>
              </div>
            </Card>
          ))}
        </div>

        {mockBookings.length === 0 && (
          <Card className="p-12 text-center">
            <CalendarDays className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h3 className="text-xl font-semibold mb-2">No Bookings Yet</h3>
            <p className="text-muted-foreground mb-4">
              Start by searching for vendors and making your first booking
            </p>
            <Button onClick={() => setLocation("/planner")}>
              Find Vendors
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
