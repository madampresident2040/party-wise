import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, DollarSign, TrendingUp, AlertTriangle, Plus, Trash2, Check } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Budget() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [eventId, setEventId] = useState<number | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Form state
  const [category, setCategory] = useState("");
  const [itemName, setItemName] = useState("");
  const [estimatedCost, setEstimatedCost] = useState("");
  const [actualCost, setActualCost] = useState("");
  const [notes, setNotes] = useState("");

  const userEvents = trpc.party.getUserEvents.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const budgetQuery = trpc.budget.list.useQuery(
    { eventId: eventId! },
    { enabled: !!eventId }
  );

  const addItemMutation = trpc.budget.addItem.useMutation({
    onSuccess: () => {
      budgetQuery.refetch();
      setIsAddDialogOpen(false);
      resetForm();
      toast.success("Budget item added!");
    },
  });

  const togglePaidMutation = trpc.budget.togglePaid.useMutation({
    onSuccess: () => {
      budgetQuery.refetch();
      toast.success("Payment status updated!");
    },
  });

  const deleteItemMutation = trpc.budget.deleteItem.useMutation({
    onSuccess: () => {
      budgetQuery.refetch();
      toast.success("Item removed");
    },
  });

  useEffect(() => {
    if (userEvents.data?.events && userEvents.data.events.length > 0 && !eventId) {
      setEventId(userEvents.data.events[0].id);
    }
  }, [userEvents.data, eventId]);

  const resetForm = () => {
    setCategory("");
    setItemName("");
    setEstimatedCost("");
    setActualCost("");
    setNotes("");
  };

  const handleAddItem = async () => {
    if (!itemName.trim() || !estimatedCost || !category || !eventId) return;

    await addItemMutation.mutateAsync({
      eventId,
      category,
      itemName: itemName.trim(),
      estimatedCost: parseInt(estimatedCost),
      actualCost: actualCost ? parseInt(actualCost) : undefined,
      notes: notes.trim() || undefined,
    });
  };

  const items = budgetQuery.data?.items || [];
  const event = userEvents.data?.events.find((e: any) => e.id === eventId);
  const totalBudget = event?.budget || 0;
  const totalEstimated = items.reduce((sum, item) => sum + item.estimatedCost, 0);
  const totalSpent = items.reduce((sum, item) => sum + (item.actualCost || item.estimatedCost), 0);
  const remaining = totalBudget - totalSpent;
  const percentUsed = totalBudget > 0 ? (totalSpent / totalBudget) * 100 : 0;

  const categories = ["Venue", "Catering", "Photography", "Decorations", "Entertainment", "Invitations", "Other"];
  const categoryTotals = categories.map(cat => ({
    name: cat,
    total: items.filter((i: any) => i.category === cat).reduce((sum: number, i: any) => sum + (i.actualCost || i.estimatedCost), 0)
  })).filter((c: any) => c.total > 0);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <DollarSign className="w-12 h-12 mx-auto text-primary" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to track your party budget.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  if (!eventId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <DollarSign className="w-12 h-12 mx-auto text-muted-foreground" />
          <h2 className="text-2xl font-bold">No Events Yet</h2>
          <p className="text-muted-foreground">
            Create a party event first to start tracking your budget.
          </p>
          <Button onClick={() => setLocation("/planner")} size="lg">
            Create Event
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <DollarSign className="w-8 h-8 text-primary" />
              Budget Tracker
            </h1>
            <p className="text-muted-foreground mt-1">
              {event?.eventName || "Your Event"}
            </p>
          </div>
          
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <Plus className="w-5 h-5" />
                Add Expense
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Budget Item</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="itemName">Item Name *</Label>
                  <Input
                    id="itemName"
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    placeholder="e.g., Venue deposit"
                  />
                </div>
                <div>
                  <Label htmlFor="estimated">Estimated Cost *</Label>
                  <Input
                    id="estimated"
                    type="number"
                    value={estimatedCost}
                    onChange={(e) => setEstimatedCost(e.target.value)}
                    placeholder="5000"
                  />
                </div>
                <div>
                  <Label htmlFor="actual">Actual Cost (if paid)</Label>
                  <Input
                    id="actual"
                    type="number"
                    value={actualCost}
                    onChange={(e) => setActualCost(e.target.value)}
                    placeholder="4800"
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Input
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Additional details"
                  />
                </div>
                <Button 
                  onClick={handleAddItem} 
                  disabled={!itemName.trim() || !estimatedCost || !category || addItemMutation.isPending}
                  className="w-full"
                >
                  {addItemMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Adding...
                    </>
                  ) : (
                    "Add Item"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Budget Overview */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Total Budget</div>
            <div className="text-3xl font-bold">${totalBudget.toLocaleString()}</div>
          </Card>
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Estimated</div>
            <div className="text-3xl font-bold text-blue-600">${totalEstimated.toLocaleString()}</div>
          </Card>
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Spent</div>
            <div className="text-3xl font-bold text-orange-600">${totalSpent.toLocaleString()}</div>
          </Card>
          <Card className={`p-6 ${remaining < 0 ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'}`}>
            <div className="text-sm mb-1" style={{ color: remaining < 0 ? '#b91c1c' : '#15803d' }}>Remaining</div>
            <div className="text-3xl font-bold" style={{ color: remaining < 0 ? '#b91c1c' : '#15803d' }}>
              ${Math.abs(remaining).toLocaleString()}
            </div>
          </Card>
        </div>

        {/* Progress Bar */}
        <Card className="p-6 mb-8">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold">Budget Usage</h3>
            <span className="text-sm text-muted-foreground">{percentUsed.toFixed(1)}% used</span>
          </div>
          <Progress value={Math.min(percentUsed, 100)} className="h-4" />
          {percentUsed > 90 && (
            <div className="flex items-center gap-2 mt-3 text-sm text-orange-600">
              <AlertTriangle className="w-4 h-4" />
              <span>Warning: You're approaching your budget limit!</span>
            </div>
          )}
          {percentUsed > 100 && (
            <div className="flex items-center gap-2 mt-3 text-sm text-red-600">
              <AlertTriangle className="w-4 h-4" />
              <span>Alert: You've exceeded your budget by ${(totalSpent - totalBudget).toLocaleString()}!</span>
            </div>
          )}
        </Card>

        {/* Category Breakdown */}
        {categoryTotals.length > 0 && (
          <Card className="p-6 mb-8">
            <h3 className="font-semibold mb-4">Spending by Category</h3>
            <div className="space-y-3">
              {categoryTotals.map((cat: any) => (
                <div key={cat.name}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{cat.name}</span>
                    <span className="font-semibold">${cat.total.toLocaleString()}</span>
                  </div>
                  <Progress value={(cat.total / totalSpent) * 100} className="h-2" />
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Items List */}
        <Card className="p-6">
          <h3 className="font-semibold mb-4">All Items</h3>
          
          {items.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <DollarSign className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>No budget items yet. Click "Add Expense" to get started!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {items.map((item: any) => (
                <Card key={item.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <Checkbox
                        checked={item.paid}
                        onCheckedChange={() => togglePaidMutation.mutate({ itemId: item.id })}
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold">{item.itemName}</h4>
                          <Badge variant="outline">{item.category}</Badge>
                          {item.paid && (
                            <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                              <Check className="w-3 h-3 mr-1" />
                              Paid
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Estimated: ${item.estimatedCost.toLocaleString()}
                          {item.actualCost && ` • Actual: $${item.actualCost.toLocaleString()}`}
                        </div>
                        {item.notes && (
                          <div className="text-xs text-muted-foreground mt-1">{item.notes}</div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <div className="text-lg font-bold">
                          ${(item.actualCost || item.estimatedCost).toLocaleString()}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteItemMutation.mutate({ itemId: item.id })}
                        disabled={deleteItemMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
