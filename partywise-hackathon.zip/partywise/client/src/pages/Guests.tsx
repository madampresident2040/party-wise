import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Users, Mail, UserPlus, Trash2, Check, X, Clock, ArrowLeft } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Guests() {
  const { isAuthenticated, loading: authLoading, user } = useAuth();
  const [location, setLocation] = useLocation();
  const [eventId, setEventId] = useState<number | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Form state
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [guestPhone, setGuestPhone] = useState("");
  const [plusOne, setPlusOne] = useState(false);
  const [dietaryRestrictions, setDietaryRestrictions] = useState("");

  const userEvents = trpc.party.getUserEvents.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const guestsQuery = trpc.guests.list.useQuery(
    { eventId: eventId! },
    { enabled: !!eventId }
  );

  const addGuestMutation = trpc.guests.add.useMutation({
    onSuccess: () => {
      guestsQuery.refetch();
      setIsAddDialogOpen(false);
      resetForm();
      toast.success("Guest added successfully!");
    },
  });

  const updateRSVPMutation = trpc.guests.updateRSVP.useMutation({
    onSuccess: () => {
      guestsQuery.refetch();
      toast.success("RSVP status updated!");
    },
  });

  const sendInviteMutation = trpc.guests.sendInvite.useMutation({
    onSuccess: () => {
      guestsQuery.refetch();
      toast.success("Invite sent!");
    },
  });

  const deleteGuestMutation = trpc.guests.delete.useMutation({
    onSuccess: () => {
      guestsQuery.refetch();
      toast.success("Guest removed");
    },
  });

  useEffect(() => {
    if (userEvents.data?.events && userEvents.data.events.length > 0 && !eventId) {
      setEventId(userEvents.data.events[0].id);
    }
  }, [userEvents.data, eventId]);

  const resetForm = () => {
    setGuestName("");
    setGuestEmail("");
    setGuestPhone("");
    setPlusOne(false);
    setDietaryRestrictions("");
  };

  const handleAddGuest = async () => {
    if (!guestName.trim() || !eventId) return;

    await addGuestMutation.mutateAsync({
      eventId,
      name: guestName.trim(),
      email: guestEmail.trim() || undefined,
      phone: guestPhone.trim() || undefined,
      plusOne,
      dietaryRestrictions: dietaryRestrictions.trim() || undefined,
    });
  };

  const handleSendInvite = async (guestId: number, guestEmail: string) => {
    if (!guestEmail) {
      toast.error("Guest must have an email to send invite");
      return;
    }

    const event = userEvents.data?.events.find((e: any) => e.id === eventId);
    await sendInviteMutation.mutateAsync({
      guestId,
      eventName: event?.eventName || "Your Party",
      eventDate: event?.eventDate?.toString(),
    });
  };

  const guests = guestsQuery.data?.guests || [];
  const attendingCount = guests.filter(g => g.rsvpStatus === "attending").length;
  const pendingCount = guests.filter(g => g.rsvpStatus === "pending").length;
  const declinedCount = guests.filter(g => g.rsvpStatus === "declined").length;

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <Users className="w-12 h-12 mx-auto text-primary" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to manage your guest list and send invites.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  if (!eventId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="p-8 max-w-md text-center space-y-4">
          <Users className="w-12 h-12 mx-auto text-muted-foreground" />
          <h2 className="text-2xl font-bold">No Events Yet</h2>
          <p className="text-muted-foreground">
            Create a party event first to start managing your guest list.
          </p>
          <Button onClick={() => setLocation("/planner")} size="lg">
            Create Event
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container py-6">
          <Button 
            variant="ghost" 
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <Users className="w-8 h-8 text-primary" />
                Guest List Manager
              </h1>
              <p className="text-muted-foreground mt-1">
                {userEvents.data?.events.find((e: any) => e.id === eventId)?.eventName || "Your Event"}
              </p>
            </div>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="lg" className="gap-2">
                  <UserPlus className="w-5 h-5" />
                  Add Guest
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Guest</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={guestEmail}
                      onChange={(e) => setGuestEmail(e.target.value)}
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={guestPhone}
                      onChange={(e) => setGuestPhone(e.target.value)}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="plusOne"
                      checked={plusOne}
                      onCheckedChange={(checked) => setPlusOne(checked as boolean)}
                    />
                    <Label htmlFor="plusOne" className="cursor-pointer">
                      Allow +1
                    </Label>
                  </div>
                  <div>
                    <Label htmlFor="dietary">Dietary Restrictions</Label>
                    <Input
                      id="dietary"
                      value={dietaryRestrictions}
                      onChange={(e) => setDietaryRestrictions(e.target.value)}
                      placeholder="Vegetarian, gluten-free, etc."
                    />
                  </div>
                  <Button 
                    onClick={handleAddGuest} 
                    disabled={!guestName.trim() || addGuestMutation.isPending}
                    className="w-full"
                  >
                    {addGuestMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        Adding...
                      </>
                    ) : (
                      "Add Guest"
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="container py-8">
        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4">
            <div className="text-2xl font-bold">{guests.length}</div>
            <div className="text-sm text-muted-foreground">Total Guests</div>
          </Card>
          <Card className="p-4 border-green-200 bg-green-50">
            <div className="text-2xl font-bold text-green-700">{attendingCount}</div>
            <div className="text-sm text-green-600">Attending</div>
          </Card>
          <Card className="p-4 border-yellow-200 bg-yellow-50">
            <div className="text-2xl font-bold text-yellow-700">{pendingCount}</div>
            <div className="text-sm text-yellow-600">Pending</div>
          </Card>
          <Card className="p-4 border-red-200 bg-red-50">
            <div className="text-2xl font-bold text-red-700">{declinedCount}</div>
            <div className="text-sm text-red-600">Declined</div>
          </Card>
        </div>

        {/* Guest List */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">All Guests</h2>
          
          {guests.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p>No guests added yet. Click "Add Guest" to get started!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {guests.map((guest) => (
                <Card key={guest.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg">{guest.name}</h3>
                        {guest.rsvpStatus === "attending" && (
                          <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                            <Check className="w-3 h-3 mr-1" />
                            Attending
                          </Badge>
                        )}
                        {guest.rsvpStatus === "declined" && (
                          <Badge variant="destructive">
                            <X className="w-3 h-3 mr-1" />
                            Declined
                          </Badge>
                        )}
                        {guest.rsvpStatus === "pending" && (
                          <Badge variant="secondary">
                            <Clock className="w-3 h-3 mr-1" />
                            Pending
                          </Badge>
                        )}
                        {guest.plusOne && (
                          <Badge variant="outline">+1</Badge>
                        )}
                      </div>
                      
                      <div className="text-sm text-muted-foreground space-y-1">
                        {guest.email && <div>📧 {guest.email}</div>}
                        {guest.phone && <div>📱 {guest.phone}</div>}
                        {guest.dietaryRestrictions && (
                          <div>🍽️ {guest.dietaryRestrictions}</div>
                        )}
                        {guest.inviteSent && (
                          <div className="text-xs text-green-600 mt-2">
                            ✓ Invite sent {guest.inviteSentAt && `on ${new Date(guest.inviteSentAt).toLocaleDateString()}`}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      {!guest.inviteSent && guest.email && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendInvite(guest.id, guest.email!)}
                          disabled={sendInviteMutation.isPending}
                        >
                          <Mail className="w-4 h-4 mr-2" />
                          Send Invite
                        </Button>
                      )}
                      
                      {guest.rsvpStatus === "pending" && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateRSVPMutation.mutate({ guestId: guest.id, status: "attending" })}
                            className="text-green-600 hover:text-green-700"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateRSVPMutation.mutate({ guestId: guest.id, status: "declined" })}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteGuestMutation.mutate({ guestId: guest.id })}
                        disabled={deleteGuestMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
