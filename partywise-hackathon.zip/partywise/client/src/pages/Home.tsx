import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Sparkles, Users, DollarSign, Calendar, Instagram, CalendarDays } from "lucide-react";
import { useLocation } from "wouter";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-background to-pink-900/20 animate-gradient"></div>
      
      {/* Decorative Elements with Enhanced Animations */}
      <div className="absolute top-8 left-8 text-6xl animate-bounce" style={{ animationDuration: '2s' }}>🌸</div>
      <div className="absolute top-12 right-12 text-7xl animate-bounce" style={{ animationDuration: '2.5s', animationDelay: '0.3s' }}>🌼</div>
      <div className="absolute bottom-20 left-16 text-5xl animate-pulse">🍷</div>
      <div className="absolute top-1/3 right-1/4 text-4xl animate-spin" style={{ animationDuration: '15s' }}>✨</div>
      <div className="absolute bottom-1/3 left-1/4 text-3xl animate-spin" style={{ animationDuration: '20s', animationDirection: 'reverse' }}>✨</div>
      <div className="absolute top-1/2 left-1/3 text-5xl animate-bounce" style={{ animationDuration: '3s', animationDelay: '0.5s' }}>🎈</div>
      <div className="absolute bottom-1/4 right-1/3 text-4xl animate-pulse" style={{ animationDelay: '1s' }}>🎊</div>
      
      <div className="container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-12">
          {/* Left Side - Text Content */}
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-4">
              <h1 className="text-7xl md:text-8xl font-party text-white leading-tight animate-slide-in-left">
                Party
                <br />
                <span className="text-primary animate-pulse">Wise</span>
              </h1>
              <p className="text-xl md:text-2xl text-foreground/90 max-w-md font-light animate-slide-in-left" style={{ animationDelay: '0.2s' }}>
                We handle the drama
                <br />
                so you don't have to
                <br />
                <span className="text-muted-foreground">(you are welcome)</span>
              </p>
            </div>

            <div className="space-y-4 animate-slide-in-left" style={{ animationDelay: '0.4s' }}>
              {isAuthenticated ? (
                <Button 
                  size="lg" 
                  className="text-lg px-8 py-6 rounded-full bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
                  onClick={() => setLocation("/themes")}
                >
                  <Sparkles className="w-5 h-5 mr-2 animate-spin" style={{ animationDuration: '3s' }} />
                  Start Planning Your Party
                </Button>
              ) : (
                <Button 
                  size="lg" 
                  className="text-lg px-8 py-6 rounded-full bg-primary hover:bg-primary/90 text-white font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
                  asChild
                >
                  <a href={getLoginUrl()}>
                    <Sparkles className="w-5 h-5 mr-2 animate-spin" style={{ animationDuration: '3s' }} />
                    Get Started Free
                  </a>
                </Button>
              )}
            </div>

            {/* Feature Pills with Staggered Animation */}
            <div className="flex flex-wrap gap-3 pt-4">
              <div className="px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-border text-sm font-medium hover:scale-110 hover:bg-card/70 transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.6s' }}>
                🎉 AI-Powered Planning
              </div>
              <div className="px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-border text-sm font-medium hover:scale-110 hover:bg-card/70 transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.7s' }}>
                💰 Budget Tracking
              </div>
              <div className="px-4 py-2 bg-card/50 backdrop-blur-sm rounded-full border border-border text-sm font-medium hover:scale-110 hover:bg-card/70 transition-all duration-300 animate-fade-in" style={{ animationDelay: '0.8s' }}>
                📸 Vendor Comparison
              </div>
            </div>
          </div>

          {/* Right Side - Animated Illustration */}
          <div className="hidden lg:block relative animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className="relative w-full h-[600px] flex items-center justify-center">
              {/* Animated decorative circles */}
              <div className="absolute top-20 left-20 w-64 h-64 bg-secondary/20 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute bottom-20 right-20 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-purple-500/10 rounded-full blur-2xl animate-ping" style={{ animationDuration: '3s' }}></div>
              
              {/* Party Icons with Complex Animations */}
              <div className="relative text-center space-y-8">
                <div className="text-9xl animate-bounce hover:scale-125 transition-transform duration-300" style={{ animationDuration: '2s' }}>🎊</div>
                <div className="flex justify-center gap-8">
                  <div className="text-6xl animate-bounce hover:rotate-12 transition-transform duration-300" style={{ animationDuration: '2.5s', animationDelay: '0.2s' }}>🎈</div>
                  <div className="text-6xl animate-bounce hover:-rotate-12 transition-transform duration-300" style={{ animationDuration: '2.5s', animationDelay: '0.4s' }}>🎉</div>
                  <div className="text-6xl animate-bounce hover:scale-125 transition-transform duration-300" style={{ animationDuration: '2.5s', animationDelay: '0.6s' }}>🎁</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Grid with Staggered Entrance */}
        <div className="pb-20">
          <h2 className="text-4xl font-bold text-center mb-12 font-party text-primary animate-fade-in">
            Everything You Need to Party
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/20 animate-fade-in-up"
              style={{ animationDelay: '0.1s' }}
              onClick={() => isAuthenticated && setLocation("/planner")}
            >
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <Sparkles className="w-6 h-6 text-primary group-hover:animate-spin" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Find Vendors</h3>
              <p className="text-muted-foreground">
                Compare venues, caterers, and photographers by zipcode with AI recommendations
              </p>
            </div>

            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-secondary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-secondary/20 animate-fade-in-up"
              style={{ animationDelay: '0.2s' }}
              onClick={() => isAuthenticated && setLocation("/social-vendors")}
            >
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <Instagram className="w-6 h-6 text-secondary group-hover:animate-pulse" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Social Vendors</h3>
              <p className="text-muted-foreground">
                Discover amazing bakers and florists from Instagram and Facebook
              </p>
            </div>

            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/20 animate-fade-in-up"
              style={{ animationDelay: '0.3s' }}
              onClick={() => isAuthenticated && setLocation("/guests")}
            >
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <Users className="w-6 h-6 text-primary group-hover:animate-bounce" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Guest List</h3>
              <p className="text-muted-foreground">
                Manage invites, track RSVPs, and send reminders all in one place
              </p>
            </div>

            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-secondary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-secondary/20 animate-fade-in-up"
              style={{ animationDelay: '0.4s' }}
              onClick={() => isAuthenticated && setLocation("/budget")}
            >
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <DollarSign className="w-6 h-6 text-secondary group-hover:animate-pulse" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Budget Tracker</h3>
              <p className="text-muted-foreground">
                Stay on budget with visual progress bars and spending alerts
              </p>
            </div>

            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-primary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/20 animate-fade-in-up"
              style={{ animationDelay: '0.5s' }}
              onClick={() => isAuthenticated && setLocation("/timeline")}
            >
              <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <Calendar className="w-6 h-6 text-primary group-hover:animate-bounce" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Planning Timeline</h3>
              <p className="text-muted-foreground">
                Never miss a milestone with AI-powered planning checklists
              </p>
            </div>

            <div 
              className="group p-6 bg-card/50 backdrop-blur-sm rounded-2xl border border-border hover:border-secondary/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:-translate-y-2 hover:shadow-2xl hover:shadow-secondary/20 animate-fade-in-up"
              style={{ animationDelay: '0.6s' }}
              onClick={() => isAuthenticated && setLocation("/booking")}
            >
              <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                <CalendarDays className="w-6 h-6 text-secondary group-hover:animate-pulse" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Booking Calendar</h3>
              <p className="text-muted-foreground">
                Track all vendor bookings and confirmations in one dashboard
              </p>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slide-in-left {
          from { opacity: 0; transform: translateX(-50px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes gradient {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.8; }
        }
        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
          opacity: 0;
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out forwards;
          opacity: 0;
        }
        .animate-slide-in-left {
          animation: slide-in-left 0.8s ease-out forwards;
          opacity: 0;
        }
        .animate-gradient {
          animation: gradient 4s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}
