import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Loader2, MapPin, DollarSign, Star, ExternalLink, MessageSquare, Send, Share2, Sparkles } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Streamdown } from "streamdown";
import { toast } from "sonner";

export default function Planner() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [location] = useLocation();
  const [zipcode, setZipcode] = useState("");
  const [eventName, setEventName] = useState("");
  const [activeTab, setActiveTab] = useState("venues");
  const [chatMessage, setChatMessage] = useState("");
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const params = new URLSearchParams(location.split("?")[1]);
    const zip = params.get("zipcode");
    if (zip) setZipcode(zip);
  }, [location]);

  const createEventMutation = trpc.party.createEvent.useMutation({
    onSuccess: (data) => {
      setCurrentEventId(data.eventId);
      toast.success("Event created! Now search for vendors.");
    },
  });
  
  const searchVendorsMutation = trpc.party.searchVendors.useMutation({
    onSuccess: (data) => {
      setVendorResults(data.vendors);
      toast.success(`Found ${data.vendors.length} ${activeTab}!`);
    },
  });
  
  const chatMutation = trpc.party.chat.useMutation();
  const shareMutation = trpc.share.generateShareData.useMutation();

  const [currentEventId, setCurrentEventId] = useState<number | null>(null);
  const [vendorResults, setVendorResults] = useState<any[]>([]);
  const [chatHistory, setChatHistory] = useState<Array<{ role: string; content: string }>>([]);

  const handleCreateEvent = async () => {
    if (!eventName.trim()) {
      toast.error("Please enter an event name");
      return;
    }
    if (!zipcode.trim()) {
      toast.error("Please enter a zipcode");
      return;
    }
    
    await createEventMutation.mutateAsync({
      eventName: eventName.trim(),
      zipcode: zipcode.trim(),
    });
  };

  const handleSearchVendors = async (vendorType: string) => {
    if (!currentEventId) {
      toast.error("Please create an event first by entering a name and zipcode above");
      return;
    }
    
    if (!zipcode.trim()) {
      toast.error("Please enter a zipcode");
      return;
    }
    
    await searchVendorsMutation.mutateAsync({
      eventId: currentEventId,
      vendorType,
      zipcode: zipcode.trim(),
    });
  };

  const handleShare = async () => {
    if (!currentEventId) return;
    
    const result = await shareMutation.mutateAsync({ eventId: currentEventId });
    
    if (result.success && navigator.share) {
      try {
        await navigator.share({
          title: `Planning ${result.eventName}`,
          text: result.shareText,
        });
      } catch (err) {
        navigator.clipboard.writeText(result.shareText);
        toast.success("Share text copied to clipboard!");
      }
    } else if (result.success) {
      navigator.clipboard.writeText(result.shareText);
      toast.success("Share text copied to clipboard!");
    }
  };

  const handleSendMessage = async () => {
    if (!chatMessage.trim() || !currentEventId) return;
    
    const userMessage = chatMessage.trim();
    setChatMessage("");
    setChatHistory(prev => [...prev, { role: "user", content: userMessage }]);
    
    const result = await chatMutation.mutateAsync({
      eventId: currentEventId,
      message: userMessage,
    });
    
    setChatHistory(prev => [...prev, { role: "assistant", content: result.response }]);
    
    setTimeout(() => {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to start planning your party and save your progress.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container">
        {/* Event Setup Card */}
        {!currentEventId && (
          <Card className="p-6 mb-6 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1 space-y-4">
                <div>
                  <h2 className="text-2xl font-bold mb-2">Let's Start Planning Your Party!</h2>
                  <p className="text-muted-foreground">Enter your event details to begin searching for vendors</p>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="eventName">Event Name</Label>
                    <Input
                      id="eventName"
                      placeholder="e.g., Sarah's Birthday Party"
                      value={eventName}
                      onChange={(e) => setEventName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleCreateEvent()}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="zipcode">Zipcode</Label>
                    <Input
                      id="zipcode"
                      placeholder="e.g., 90210"
                      value={zipcode}
                      onChange={(e) => setZipcode(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleCreateEvent()}
                    />
                  </div>
                </div>
                
                <Button 
                  onClick={handleCreateEvent} 
                  disabled={createEventMutation.isPending}
                  size="lg"
                  className="w-full md:w-auto"
                >
                  {createEventMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Creating Event...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Start Planning
                    </>
                  )}
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Header for existing event */}
        {currentEventId && (
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold">{eventName}</h1>
              <div className="flex items-center gap-2 mt-1 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>{zipcode}</span>
              </div>
            </div>
            <Button onClick={handleShare} variant="outline" disabled={shareMutation.isPending}>
              <Share2 className="w-4 h-4 mr-2" />
              Share Event
            </Button>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content - Vendor Search */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-6">
              <h2 className="text-2xl font-semibold mb-4">Find Vendors & Products</h2>
              
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-5 w-full">
                  <TabsTrigger value="venues">Venues</TabsTrigger>
                  <TabsTrigger value="caterers">Caterers</TabsTrigger>
                  <TabsTrigger value="photographers">Photos</TabsTrigger>
                  <TabsTrigger value="bakers">Bakers</TabsTrigger>
                  <TabsTrigger value="amazon">Amazon</TabsTrigger>
                </TabsList>

                {["venues", "caterers", "photographers", "bakers", "amazon"].map((type) => (
                  <TabsContent key={type} value={type} className="space-y-4 mt-6">
                    <Button 
                      onClick={() => handleSearchVendors(type)}
                      disabled={!currentEventId || searchVendorsMutation.isPending}
                      className="w-full"
                      size="lg"
                    >
                      {searchVendorsMutation.isPending ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          Searching...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Search {type.charAt(0).toUpperCase() + type.slice(1)} in {zipcode || "your area"}
                        </>
                      )}
                    </Button>

                    {vendorResults.length > 0 && (
                      <div className="space-y-3">
                        {vendorResults.map((vendor, idx) => (
                          <Card key={idx} className="p-4 hover:shadow-md transition-shadow">
                            <div className="flex justify-between items-start">
                              <div className="flex-1">
                                <h3 className="font-semibold text-lg">{vendor.name}</h3>
                                <p className="text-sm text-muted-foreground mt-1">{vendor.description}</p>
                                <div className="flex items-center gap-4 mt-3">
                                  {vendor.price && (
                                    <div className="flex items-center gap-1 text-primary">
                                      <DollarSign className="w-4 h-4" />
                                      <span className="font-semibold">{vendor.price}</span>
                                    </div>
                                  )}
                                  {vendor.rating && (
                                    <div className="flex items-center gap-1">
                                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                                      <span className="text-sm">{vendor.rating}</span>
                                    </div>
                                  )}
                                  {vendor.badge && (
                                    <Badge variant="secondary">{vendor.badge}</Badge>
                                  )}
                                </div>
                              </div>
                              {vendor.link && (
                                <Button variant="outline" size="sm" asChild>
                                  <a href={vendor.link} target="_blank" rel="noopener noreferrer">
                                    <ExternalLink className="w-4 h-4" />
                                  </a>
                                </Button>
                              )}
                            </div>
                          </Card>
                        ))}
                      </div>
                    )}
                  </TabsContent>
                ))}
              </Tabs>
            </Card>
          </div>

          {/* Sidebar - AI Chat */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-24 h-[calc(100vh-8rem)] flex flex-col">
              <div className="flex items-center gap-2 mb-4">
                <MessageSquare className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-semibold">AI Planning Assistant</h2>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 mb-4">
                {chatHistory.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    <p>Ask me anything about planning your party!</p>
                    <p className="text-sm mt-2">I can help with timelines, budgets, and next steps.</p>
                  </div>
                ) : (
                  chatHistory.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-lg ${
                        msg.role === "user"
                          ? "bg-primary text-primary-foreground ml-4"
                          : "bg-muted mr-4"
                      }`}
                    >
                      <Streamdown>{msg.content}</Streamdown>
                    </div>
                  ))
                )}
                <div ref={chatEndRef} />
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="Ask for planning advice..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                  disabled={!currentEventId || chatMutation.isPending}
                />
                <Button 
                  onClick={handleSendMessage}
                  disabled={!currentEventId || !chatMessage.trim() || chatMutation.isPending}
                  size="icon"
                >
                  {chatMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
