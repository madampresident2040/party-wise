import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Instagram, Facebook, Heart, MapPin, DollarSign, ExternalLink, ArrowLeft } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function SocialVendors() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [location, setLocation] = useLocation();
  const [zipcode, setZipcode] = useState("");
  const [vendorType, setVendorType] = useState("bakers");
  const [selectedVendors, setSelectedVendors] = useState<Set<number>>(new Set());
  const [vendors, setVendors] = useState<any[]>([]);

  const searchMutation = trpc.party.searchSocialVendors.useMutation();

  const handleSearch = async () => {
    if (!zipcode.trim()) return;
    
    const result = await searchMutation.mutateAsync({
      vendorType,
      zipcode: zipcode.trim(),
    });
    
    setVendors(result.vendors || []);
  };

  const toggleVendorSelection = (index: number) => {
    const newSelected = new Set(selectedVendors);
    if (newSelected.has(index)) {
      newSelected.delete(index);
    } else {
      newSelected.add(index);
    }
    setSelectedVendors(newSelected);
  };

  const selectedVendorsList = Array.from(selectedVendors).map(idx => vendors[idx]).filter(Boolean);

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <Instagram className="w-12 h-12 mx-auto text-primary" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to discover amazing vendors from Instagram and Facebook.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="container py-6">
          <Button 
            variant="ghost" 
            onClick={() => setLocation("/")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
          
          <div className="flex items-center gap-3 mb-4">
            <div className="flex gap-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center">
                <Instagram className="w-6 h-6 text-white" />
              </div>
              <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
                <Facebook className="w-6 h-6 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-3xl font-bold">Social Media Vendors</h1>
              <p className="text-muted-foreground">Discover talented local vendors from Instagram & Facebook</p>
            </div>
          </div>

          {/* Search Bar */}
          <div className="flex gap-3 max-w-2xl">
            <Input
              placeholder="Enter zipcode"
              value={zipcode}
              onChange={(e) => setZipcode(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={!zipcode.trim() || searchMutation.isPending}>
              {searchMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Searching...
                </>
              ) : (
                "Search"
              )}
            </Button>
          </div>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content - Vendor List */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-6">
              <Tabs value={vendorType} onValueChange={setVendorType}>
                <TabsList className="grid grid-cols-4 w-full">
                  <TabsTrigger value="bakers">Bakers</TabsTrigger>
                  <TabsTrigger value="florists">Florists</TabsTrigger>
                  <TabsTrigger value="decorators">Decorators</TabsTrigger>
                  <TabsTrigger value="djs">DJs</TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="mt-6 space-y-4">
                {vendors.length === 0 && !searchMutation.isPending && (
                  <div className="text-center py-12 text-muted-foreground">
                    <Instagram className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>Enter a zipcode and search to discover local vendors</p>
                  </div>
                )}

                {vendors.map((vendor, idx) => (
                  <Card 
                    key={idx} 
                    className={`p-4 hover:shadow-md transition-all ${selectedVendors.has(idx) ? 'ring-2 ring-primary' : ''}`}
                  >
                    <div className="flex gap-4">
                      <Checkbox
                        checked={selectedVendors.has(idx)}
                        onCheckedChange={() => toggleVendorSelection(idx)}
                        className="mt-1"
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg flex items-center gap-2">
                              {vendor.name}
                              {vendor.source === "Instagram" && (
                                <Instagram className="w-4 h-4 text-pink-600" />
                              )}
                              {vendor.source === "Facebook" && (
                                <Facebook className="w-4 h-4 text-blue-600" />
                              )}
                            </h3>
                            <p className="text-sm text-muted-foreground">{vendor.description}</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 mt-3 flex-wrap">
                          {vendor.price && (
                            <div className="flex items-center gap-1 text-primary">
                              <DollarSign className="w-4 h-4" />
                              <span className="font-semibold">{vendor.price}</span>
                            </div>
                          )}
                          
                          {vendor.followers && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Heart className="w-4 h-4" />
                              <span>{vendor.followers} followers</span>
                            </div>
                          )}

                          {vendor.location && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <MapPin className="w-4 h-4" />
                              <span>{vendor.location}</span>
                            </div>
                          )}

                          {vendor.badge && (
                            <Badge variant="secondary">{vendor.badge}</Badge>
                          )}
                        </div>

                        {vendor.link && (
                          <Button variant="outline" size="sm" asChild className="mt-3">
                            <a href={vendor.link} target="_blank" rel="noopener noreferrer">
                              View Profile
                              <ExternalLink className="w-3 h-3 ml-2" />
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </div>

          {/* Sidebar - Comparison */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-6">
              <h2 className="text-xl font-semibold mb-4">
                Compare Selected ({selectedVendors.size})
              </h2>

              {selectedVendorsList.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  <p>Select vendors to compare them side-by-side</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {selectedVendorsList.map((vendor, idx) => (
                    <div key={idx} className="p-3 bg-muted rounded-lg">
                      <div className="flex items-start justify-between mb-1">
                        <h3 className="font-semibold text-sm">{vendor.name}</h3>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const vendorIdx = vendors.findIndex(v => v.name === vendor.name);
                            toggleVendorSelection(vendorIdx);
                          }}
                          className="h-6 w-6 p-0"
                        >
                          ×
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{vendor.description}</p>
                      {vendor.price && (
                        <div className="text-sm font-semibold text-primary">{vendor.price}</div>
                      )}
                    </div>
                  ))}

                  {selectedVendorsList.length >= 2 && (
                    <div className="pt-4 border-t">
                      <h3 className="font-semibold mb-2 text-sm">Quick Comparison</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Lowest Price:</span>
                          <span className="font-semibold">
                            {selectedVendorsList.reduce((min, v) => {
                              const price = v.price?.replace(/[^0-9]/g, '') || '999999';
                              const minPrice = min.price?.replace(/[^0-9]/g, '') || '999999';
                              return parseInt(price) < parseInt(minPrice) ? v : min;
                            }).name}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
