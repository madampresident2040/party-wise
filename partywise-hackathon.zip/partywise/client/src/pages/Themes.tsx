import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Cake, Heart, Briefcase, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface ThemePreset {
  id: string;
  name: string;
  type: "birthday" | "wedding" | "corporate";
  description: string;
  budgetRange: string;
  icon: React.ReactNode;
  color: string;
  vendors: string[];
  milestones: string[];
}

const themePresets: ThemePreset[] = [
  {
    id: "birthday",
    name: "Birthday Bash",
    type: "birthday",
    description: "Perfect for milestone birthdays, sweet sixteens, and celebration parties",
    budgetRange: "$2,000 - $10,000",
    icon: <Cake className="w-8 h-8" />,
    color: "from-pink-500 to-purple-500",
    vendors: ["Party Venue", "Cake Baker", "DJ/Entertainment", "Photographer", "Decorator"],
    milestones: [
      "Book venue (8 weeks before)",
      "Order custom cake (4 weeks before)",
      "Send invitations (3 weeks before)",
      "Confirm entertainment (2 weeks before)",
      "Final headcount (1 week before)",
    ],
  },
  {
    id: "wedding",
    name: "Dream Wedding",
    type: "wedding",
    description: "Elegant planning for your special day with all the essentials",
    budgetRange: "$15,000 - $50,000",
    icon: <Heart className="w-8 h-8" />,
    color: "from-rose-400 to-pink-600",
    vendors: ["Wedding Venue", "Caterer", "Photographer", "Florist", "Wedding Planner", "Baker"],
    milestones: [
      "Book venue and caterer (12 months before)",
      "Select photographer (9 months before)",
      "Order flowers (6 months before)",
      "Send save-the-dates (6 months before)",
      "Final vendor confirmations (1 month before)",
    ],
  },
  {
    id: "corporate",
    name: "Corporate Event",
    type: "corporate",
    description: "Professional events, team building, and company celebrations",
    budgetRange: "$5,000 - $25,000",
    icon: <Briefcase className="w-8 h-8" />,
    color: "from-blue-500 to-indigo-600",
    vendors: ["Conference Venue", "Catering Service", "AV Equipment", "Photographer", "Event Coordinator"],
    milestones: [
      "Secure venue (12 weeks before)",
      "Book catering (8 weeks before)",
      "Arrange AV equipment (6 weeks before)",
      "Send invitations (4 weeks before)",
      "Confirm all vendors (1 week before)",
    ],
  },
];

export default function Themes() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);

  const handleSelectTheme = (theme: ThemePreset) => {
    setSelectedTheme(theme.id);
    toast.success(`${theme.name} theme selected!`, {
      description: "Your planning dashboard will be customized with recommended vendors and timeline.",
    });
    
    // Navigate to planner with theme preset
    setTimeout(() => {
      setLocation(`/planner?theme=${theme.id}`);
    }, 1500);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 max-w-md text-center">
          <h2 className="text-2xl font-bold mb-4">Sign In Required</h2>
          <p className="text-muted-foreground mb-6">
            Please sign in to access party themes and start planning your event.
          </p>
          <Button asChild>
            <a href="/api/oauth/login">Sign In</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-20 pb-12">
      <div className="container">
        {/* Header */}
        <div className="text-center mb-12 animate-fade-in-up">
          <h1 className="text-5xl font-party text-primary mb-4 flex items-center justify-center gap-3">
            <Sparkles className="w-10 h-10 animate-spin" style={{ animationDuration: '3s' }} />
            Choose Your Party Theme
            <Sparkles className="w-10 h-10 animate-spin" style={{ animationDuration: '3s', animationDirection: 'reverse' }} />
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Select a preset theme to get started with recommended vendors, budget ranges, and planning timelines
          </p>
        </div>

        {/* Theme Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {themePresets.map((theme, index) => (
            <Card
              key={theme.id}
              className={`group relative overflow-hidden cursor-pointer transition-all duration-300 hover:scale-105 hover:-translate-y-2 hover:shadow-2xl ${
                selectedTheme === theme.id ? "ring-4 ring-primary" : ""
              } animate-fade-in-up`}
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => handleSelectTheme(theme)}
            >
              {/* Gradient Background */}
              <div className={`absolute inset-0 bg-gradient-to-br ${theme.color} opacity-10 group-hover:opacity-20 transition-opacity`}></div>

              <div className="relative p-6 space-y-4">
                {/* Icon */}
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${theme.color} flex items-center justify-center text-white group-hover:scale-110 group-hover:rotate-12 transition-all duration-300`}>
                  {theme.icon}
                </div>

                {/* Title */}
                <div>
                  <h3 className="text-2xl font-bold mb-2">{theme.name}</h3>
                  <p className="text-sm text-muted-foreground">{theme.description}</p>
                </div>

                {/* Budget Range */}
                <div className="py-3 px-4 bg-card/50 rounded-lg border border-border">
                  <p className="text-sm text-muted-foreground">Budget Range</p>
                  <p className="text-lg font-semibold">{theme.budgetRange}</p>
                </div>

                {/* Vendors */}
                <div>
                  <p className="text-sm font-semibold mb-2">Recommended Vendors:</p>
                  <div className="flex flex-wrap gap-2">
                    {theme.vendors.slice(0, 3).map((vendor) => (
                      <span
                        key={vendor}
                        className="text-xs px-2 py-1 bg-muted rounded-full"
                      >
                        {vendor}
                      </span>
                    ))}
                    {theme.vendors.length > 3 && (
                      <span className="text-xs px-2 py-1 bg-muted rounded-full">
                        +{theme.vendors.length - 3} more
                      </span>
                    )}
                  </div>
                </div>

                {/* Milestones Preview */}
                <div>
                  <p className="text-sm font-semibold mb-2">Planning Timeline:</p>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {theme.milestones.slice(0, 3).map((milestone, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-primary">✓</span>
                        <span>{milestone}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Select Button */}
                <Button
                  className={`w-full bg-gradient-to-r ${theme.color} hover:opacity-90 text-white font-semibold`}
                  size="lg"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Select This Theme
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {/* Custom Theme Option */}
        <div className="mt-12 text-center animate-fade-in" style={{ animationDelay: '0.4s' }}>
          <p className="text-muted-foreground mb-4">Don't see what you're looking for?</p>
          <Button
            variant="outline"
            size="lg"
            onClick={() => setLocation("/planner")}
            className="hover:scale-105 transition-transform"
          >
            Create Custom Event
          </Button>
        </div>
      </div>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
          opacity: 0;
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out forwards;
          opacity: 0;
        }
      `}</style>
    </div>
  );
}
