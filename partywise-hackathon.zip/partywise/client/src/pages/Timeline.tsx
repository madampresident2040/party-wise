import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Calendar, CheckCircle2, Clock } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

const defaultTasks = [
  { id: 1, title: "Set budget and guest count", weeks: 24, category: "Planning", completed: false },
  { id: 2, title: "Choose and book venue", weeks: 20, category: "Venue", completed: false },
  { id: 3, title: "Hire caterer", weeks: 16, category: "Catering", completed: false },
  { id: 4, title: "Book photographer/videographer", weeks: 16, category: "Photography", completed: false },
  { id: 5, title: "Send save-the-dates", weeks: 12, category: "Invitations", completed: false },
  { id: 6, title: "Order decorations", weeks: 10, category: "Decorations", completed: false },
  { id: 7, title: "Book entertainment/DJ", weeks: 8, category: "Entertainment", completed: false },
  { id: 8, title: "Send formal invitations", weeks: 6, category: "Invitations", completed: false },
  { id: 9, title: "Finalize menu with caterer", weeks: 4, category: "Catering", completed: false },
  { id: 10, title: "Confirm all vendor bookings", weeks: 2, category: "Planning", completed: false },
  { id: 11, title: "Final guest count to venue", weeks: 1, category: "Planning", completed: false },
  { id: 12, title: "Day-of timeline creation", weeks: 1, category: "Planning", completed: false },
];

export default function Timeline() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [tasks, setTasks] = useState(defaultTasks);

  const toggleTask = (id: number) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const completedCount = tasks.filter(t => t.completed).length;
  const progress = (completedCount / tasks.length) * 100;

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-accent/5 to-secondary/10">
        <Card className="p-8 max-w-md text-center space-y-4">
          <Calendar className="w-12 h-12 mx-auto text-primary" />
          <h2 className="text-2xl font-bold">Sign In Required</h2>
          <p className="text-muted-foreground">
            Please sign in to access your party planning timeline.
          </p>
          <Button asChild size="lg" className="w-full">
            <a href={getLoginUrl()}>Sign In to Continue</a>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Calendar className="w-8 h-8 text-primary" />
            Party Planning Timeline
          </h1>
          <p className="text-muted-foreground mt-1">
            Stay on track with AI-powered milestone recommendations
          </p>
        </div>

        {/* Progress Overview */}
        <Card className="p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-2xl font-bold">{completedCount} / {tasks.length} Tasks Complete</h3>
              <p className="text-sm text-muted-foreground">You're {progress.toFixed(0)}% done!</p>
            </div>
            <div className="text-right">
              <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-2" />
              <Badge variant="secondary">{tasks.length - completedCount} remaining</Badge>
            </div>
          </div>
          <div className="w-full bg-muted rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-primary to-accent h-3 rounded-full transition-all"
              style={{ width: `${progress}%` }}
            />
          </div>
        </Card>

        {/* Timeline */}
        <div className="space-y-6">
          {[24, 20, 16, 12, 10, 8, 6, 4, 2, 1].map(weekMark => {
            const weekTasks = tasks.filter(t => t.weeks === weekMark);
            if (weekTasks.length === 0) return null;

            return (
              <div key={weekMark} className="relative">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-24 flex-shrink-0">
                    <Badge variant="outline" className="text-sm">
                      <Clock className="w-3 h-3 mr-1" />
                      {weekMark}w before
                    </Badge>
                  </div>
                  <div className="h-px bg-border flex-1" />
                </div>

                <div className="ml-28 space-y-3">
                  {weekTasks.map(task => (
                    <Card 
                      key={task.id} 
                      className={`p-4 transition-all ${task.completed ? 'bg-green-50 border-green-200' : 'hover:shadow-md'}`}
                    >
                      <div className="flex items-center gap-4">
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={() => toggleTask(task.id)}
                          className="flex-shrink-0"
                        />
                        <div className="flex-1">
                          <h4 className={`font-semibold ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                            {task.title}
                          </h4>
                          <Badge variant="secondary" className="mt-1">
                            {task.category}
                          </Badge>
                        </div>
                        {task.completed && (
                          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
