CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `party_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventName` varchar(255) NOT NULL,
	`eventType` varchar(100),
	`zipcode` varchar(20) NOT NULL,
	`guestCount` int,
	`budget` int,
	`eventDate` timestamp,
	`status` enum('planning','booked','completed') NOT NULL DEFAULT 'planning',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `party_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `vendor_searches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`vendorType` varchar(50) NOT NULL,
	`zipcode` varchar(20) NOT NULL,
	`searchResults` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `vendor_searches_id` PRIMARY KEY(`id`)
);
