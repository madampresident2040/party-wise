CREATE TABLE `guests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320),
	`phone` varchar(50),
	`rsvpStatus` enum('pending','attending','declined') NOT NULL DEFAULT 'pending',
	`plusOne` boolean NOT NULL DEFAULT false,
	`dietaryRestrictions` text,
	`inviteSent` boolean NOT NULL DEFAULT false,
	`inviteSentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `guests_id` PRIMARY KEY(`id`)
);
