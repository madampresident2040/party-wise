CREATE TABLE `budget_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`eventId` int NOT NULL,
	`category` varchar(100) NOT NULL,
	`itemName` varchar(255) NOT NULL,
	`estimatedCost` int NOT NULL,
	`actualCost` int,
	`paid` boolean NOT NULL DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `budget_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `party_events` MODIFY COLUMN `status` enum('planning','confirmed','completed') NOT NULL DEFAULT 'planning';--> statement-breakpoint
ALTER TABLE `party_events` ADD `spentAmount` int DEFAULT 0 NOT NULL;