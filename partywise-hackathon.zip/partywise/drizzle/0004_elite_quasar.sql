CREATE TABLE `party_theme_presets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`type` enum('birthday','wedding','corporate') NOT NULL,
	`description` text,
	`budget_min` int,
	`budget_max` int,
	`icon` varchar(50),
	`color` varchar(50),
	`recommended_vendors` text,
	`timeline` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `party_theme_presets_id` PRIMARY KEY(`id`)
);
