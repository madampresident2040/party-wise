import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const partyEvents = mysqlTable("party_events", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  eventName: varchar("eventName", { length: 255 }).notNull(),
  zipcode: varchar("zipcode", { length: 20 }).notNull(),
  eventType: varchar("eventType", { length: 100 }),
  eventDate: timestamp("eventDate"),
  guestCount: int("guestCount"),
  budget: int("budget"),
  spentAmount: int("spentAmount").default(0).notNull(),
  status: mysqlEnum("status", ["planning", "confirmed", "completed"]).default("planning").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  category: varchar("category", { length: 100 }).notNull(),
  itemName: varchar("itemName", { length: 255 }).notNull(),
  estimatedCost: int("estimatedCost").notNull(),
  actualCost: int("actualCost"),
  paid: boolean("paid").default(false).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PartyEvent = typeof partyEvents.$inferSelect;
export type InsertPartyEvent = typeof partyEvents.$inferInsert;

export type BudgetItem = typeof budgetItems.$inferSelect;
export type InsertBudgetItem = typeof budgetItems.$inferInsert;

export const vendorSearches = mysqlTable("vendor_searches", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  vendorType: varchar("vendorType", { length: 50 }).notNull(),
  zipcode: varchar("zipcode", { length: 20 }).notNull(),
  searchResults: text("searchResults"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type VendorSearch = typeof vendorSearches.$inferSelect;
export type InsertVendorSearch = typeof vendorSearches.$inferInsert;

export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

export const guests = mysqlTable("guests", {
  id: int("id").autoincrement().primaryKey(),
  eventId: int("eventId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  rsvpStatus: mysqlEnum("rsvpStatus", ["pending", "attending", "declined"]).default("pending").notNull(),
  plusOne: boolean("plusOne").default(false).notNull(),
  dietaryRestrictions: text("dietaryRestrictions"),
  inviteSent: boolean("inviteSent").default(false).notNull(),
  inviteSentAt: timestamp("inviteSentAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Guest = typeof guests.$inferSelect;
export type InsertGuest = typeof guests.$inferInsert;

export const partyThemePresets = mysqlTable("party_theme_presets", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  type: mysqlEnum("type", ["birthday", "wedding", "corporate"]).notNull(),
  description: text("description"),
  budgetMin: int("budget_min"),
  budgetMax: int("budget_max"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 50 }),
  recommendedVendors: text("recommended_vendors"), // JSON string
  timeline: text("timeline"), // JSON string
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PartyThemePreset = typeof partyThemePresets.$inferSelect;
export type InsertPartyThemePreset = typeof partyThemePresets.$inferInsert;
