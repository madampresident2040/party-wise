import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  partyEvents, 
  InsertPartyEvent, 
  vendorSearches, 
  InsertVendorSearch,
  chatMessages,
  InsertChatMessage,
  guests,
  InsertGuest,
  budgetItems,
  InsertBudgetItem
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createPartyEvent(event: InsertPartyEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [result] = await db.insert(partyEvents).values(event);
  return { insertId: result.insertId };
}

export async function getUserPartyEvents(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(partyEvents).where(eq(partyEvents.userId, userId)).orderBy(desc(partyEvents.createdAt));
}

export async function getPartyEventById(eventId: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(partyEvents).where(eq(partyEvents.id, eventId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function saveVendorSearch(search: InsertVendorSearch) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(vendorSearches).values(search);
}

export async function getVendorSearchesByEvent(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(vendorSearches).where(eq(vendorSearches.eventId, eventId)).orderBy(desc(vendorSearches.createdAt));
}

export async function saveChatMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(chatMessages).values(message);
}

export async function getChatMessagesByEvent(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(chatMessages).where(eq(chatMessages.eventId, eventId)).orderBy(chatMessages.createdAt);
}

export async function addGuest(guest: InsertGuest) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [result] = await db.insert(guests).values(guest);
  return { insertId: result.insertId };
}

export async function getGuestsByEvent(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(guests).where(eq(guests.eventId, eventId)).orderBy(guests.createdAt);
}

export async function updateGuestRSVP(guestId: number, status: "pending" | "attending" | "declined") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(guests).set({ rsvpStatus: status }).where(eq(guests.id, guestId));
}

export async function markInviteSent(guestId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(guests).set({ 
    inviteSent: true, 
    inviteSentAt: new Date() 
  }).where(eq(guests.id, guestId));
}

export async function deleteGuest(guestId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(guests).where(eq(guests.id, guestId));
}

export async function addBudgetItem(item: InsertBudgetItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [result] = await db.insert(budgetItems).values(item);
  return { insertId: result.insertId };
}

export async function getBudgetItems(eventId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(budgetItems).where(eq(budgetItems.eventId, eventId)).orderBy(budgetItems.createdAt);
}

export async function toggleBudgetItemPaid(itemId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const [item] = await db.select().from(budgetItems).where(eq(budgetItems.id, itemId)).limit(1);
  if (item) {
    await db.update(budgetItems).set({ paid: !item.paid }).where(eq(budgetItems.id, itemId));
  }
}

export async function deleteBudgetItem(itemId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(budgetItems).where(eq(budgetItems.id, itemId));
}
