import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("guests", () => {
  it("adds a guest to an event", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Test Party",
      zipcode: "94102",
    });

    const guestResult = await caller.guests.add({
      eventId: eventResult.eventId,
      name: "John Doe",
      email: "john@example.com",
      plusOne: true,
    });

    expect(guestResult).toHaveProperty("guestId");
    expect(typeof guestResult.guestId).toBe("number");
    expect(guestResult.guestId).toBeGreaterThan(0);
  });

  it("lists guests for an event", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Wedding",
      zipcode: "10001",
    });

    await caller.guests.add({
      eventId: eventResult.eventId,
      name: "Jane Smith",
      email: "jane@example.com",
    });

    const guestList = await caller.guests.list({
      eventId: eventResult.eventId,
    });

    expect(guestList).toHaveProperty("guests");
    expect(Array.isArray(guestList.guests)).toBe(true);
    expect(guestList.guests.length).toBeGreaterThan(0);
    expect(guestList.guests[0]).toHaveProperty("name");
    expect(guestList.guests[0]).toHaveProperty("rsvpStatus");
  });

  it("updates guest RSVP status", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Birthday",
      zipcode: "90210",
    });

    const guestResult = await caller.guests.add({
      eventId: eventResult.eventId,
      name: "Bob Johnson",
      email: "bob@example.com",
    });

    const updateResult = await caller.guests.updateRSVP({
      guestId: guestResult.guestId,
      status: "attending",
    });

    expect(updateResult.success).toBe(true);
  });
});
