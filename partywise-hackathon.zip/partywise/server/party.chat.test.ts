import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("party.chat", () => {
  it("sends message and receives AI response", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Birthday Party",
      zipcode: "94102",
    });

    const chatResult = await caller.party.chat({
      eventId: eventResult.eventId,
      message: "What should I do first to plan my party?",
    });

    expect(chatResult).toHaveProperty("response");
    expect(typeof chatResult.response).toBe("string");
    expect(chatResult.response.length).toBeGreaterThan(0);
  }, 30000);

  it("maintains conversation context", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Wedding",
      zipcode: "10001",
    });

    const firstMessage = await caller.party.chat({
      eventId: eventResult.eventId,
      message: "I need help planning a wedding for 100 guests",
    });

    expect(firstMessage.response).toBeTruthy();

    const secondMessage = await caller.party.chat({
      eventId: eventResult.eventId,
      message: "What's a good budget for that?",
    });

    expect(secondMessage.response).toBeTruthy();
    expect(typeof secondMessage.response).toBe("string");
  }, 60000);
});
