import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("party.createEvent", () => {
  it("creates a party event and returns event ID", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.party.createEvent({
      eventName: "Birthday Party",
      zipcode: "94102",
      eventType: "birthday",
      guestCount: 50,
      budget: 5000,
    });

    expect(result).toHaveProperty("eventId");
    expect(typeof result.eventId).toBe("number");
    expect(result.eventId).toBeGreaterThan(0);
  });

  it("creates event with minimal required fields", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.party.createEvent({
      eventName: "Simple Party",
      zipcode: "10001",
    });

    expect(result).toHaveProperty("eventId");
    expect(typeof result.eventId).toBe("number");
  });
});
