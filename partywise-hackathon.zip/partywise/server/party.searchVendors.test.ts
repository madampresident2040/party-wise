import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("party.searchVendors", () => {
  it("searches for venues and returns vendor results", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Test Event",
      zipcode: "94102",
    });

    const searchResult = await caller.party.searchVendors({
      eventId: eventResult.eventId,
      vendorType: "venues",
      zipcode: "94102",
    });

    expect(searchResult).toHaveProperty("vendors");
    expect(Array.isArray(searchResult.vendors)).toBe(true);
    
    if (searchResult.vendors.length > 0) {
      const vendor = searchResult.vendors[0];
      expect(vendor).toHaveProperty("name");
      expect(vendor).toHaveProperty("description");
      expect(vendor).toHaveProperty("price");
      expect(vendor).toHaveProperty("source");
    }
  }, 30000);

  it("searches for caterers with AI integration", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const eventResult = await caller.party.createEvent({
      eventName: "Wedding",
      zipcode: "10001",
    });

    const searchResult = await caller.party.searchVendors({
      eventId: eventResult.eventId,
      vendorType: "caterers",
      zipcode: "10001",
    });

    expect(searchResult).toHaveProperty("vendors");
    expect(Array.isArray(searchResult.vendors)).toBe(true);
  }, 30000);
});
