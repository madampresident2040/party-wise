import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { 
  createPartyEvent,
  getUserPartyEvents,
  saveVendorSearch, 
  saveChatMessage, 
  getChatMessagesByEvent,
  addGuest,
  getGuestsByEvent,
  updateGuestRSVP,
  markInviteSent,
  deleteGuest,
  addBudgetItem,
  getBudgetItems,
  toggleBudgetItemPaid,
  deleteBudgetItem
} from "./db";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  party: router({
    getUserEvents: protectedProcedure
      .query(async ({ ctx }) => {
        const events = await getUserPartyEvents(ctx.user.id);
        return { events };
      }),

    createEvent: protectedProcedure
      .input(z.object({
        eventName: z.string(),
        zipcode: z.string(),
        eventType: z.string().optional(),
        guestCount: z.number().optional(),
        budget: z.number().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const result = await createPartyEvent({
          userId: ctx.user.id,
          eventName: input.eventName,
          zipcode: input.zipcode,
          eventType: input.eventType,
          guestCount: input.guestCount,
          budget: input.budget,
        });
        
        return { eventId: Number(result.insertId) };
      }),

    searchVendors: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        vendorType: z.string(),
        zipcode: z.string(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `You are a party planning assistant. Generate realistic vendor recommendations for ${input.vendorType} in zipcode ${input.zipcode}.

Return a JSON array of 5-8 vendors with this structure:
[
  {
    "name": "Vendor Name",
    "description": "Brief description of services",
    "price": "$500-1000" or "$$" or specific price,
    "rating": "4.5" (number as string),
    "badge": "Best Value" or "Best Price" or "Top Rated" (optional),
    "link": "https://example.com" (can be placeholder),
    "source": "Instagram" or "Facebook" or "Amazon" or "Local Directory"
  }
]

For Amazon products, focus on party supplies, decorations, or equipment.
For social media vendors (bakers, florists), emphasize small local businesses.
Include a mix of price points and highlight 1-2 with "Best Value" or "Best Price" badges.`;

        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: "You are a helpful party planning assistant that returns valid JSON." },
              { role: "user", content: prompt }
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "vendor_results",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    vendors: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          description: { type: "string" },
                          price: { type: "string" },
                          rating: { type: "string" },
                          badge: { type: "string" },
                          link: { type: "string" },
                          source: { type: "string" }
                        },
                        required: ["name", "description", "price", "source"],
                        additionalProperties: false
                      }
                    }
                  },
                  required: ["vendors"],
                  additionalProperties: false
                }
              }
            }
          });

          const content = response.choices[0]?.message?.content || "{}";
          const contentStr = typeof content === 'string' ? content : '{}';
          const parsed = JSON.parse(contentStr);
          const vendors = parsed.vendors || [];

          await saveVendorSearch({
            eventId: input.eventId,
            vendorType: input.vendorType,
            zipcode: input.zipcode,
            searchResults: JSON.stringify(vendors),
          });

          return { vendors };
        } catch (error) {
          console.error("Vendor search error:", error);
          return { vendors: [] };
        }
      }),

    searchSocialVendors: protectedProcedure
      .input(z.object({
        vendorType: z.string(),
        zipcode: z.string(),
      }))
      .mutation(async ({ input }) => {
        const prompt = `You are a party planning assistant. Generate realistic social media vendor recommendations for ${input.vendorType} in zipcode ${input.zipcode}.

These are small local businesses found on Instagram and Facebook. Return a JSON array of 6-10 vendors with this structure:
[
  {
    "name": "Vendor/Business Name",
    "description": "Brief description of their specialty",
    "price": "$50-200" or "$$" or specific price range,
    "followers": "2.5K" or "15K" (Instagram/Facebook followers),
    "location": "City, State" or neighborhood,
    "badge": "Trending" or "Top Rated" or "Best Value" (optional),
    "link": "https://instagram.com/..." or "https://facebook.com/..." (placeholder),
    "source": "Instagram" or "Facebook"
  }
]

Make them feel authentic with realistic follower counts and local business vibes.`;

        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: "You are a helpful party planning assistant that returns valid JSON." },
              { role: "user", content: prompt }
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "social_vendor_results",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    vendors: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          name: { type: "string" },
                          description: { type: "string" },
                          price: { type: "string" },
                          followers: { type: "string" },
                          location: { type: "string" },
                          badge: { type: "string" },
                          link: { type: "string" },
                          source: { type: "string" }
                        },
                        required: ["name", "description", "price", "source"],
                        additionalProperties: false
                      }
                    }
                  },
                  required: ["vendors"],
                  additionalProperties: false
                }
              }
            }
          });

          const content = response.choices[0]?.message?.content || "{}";
          const contentStr = typeof content === 'string' ? content : '{}';
          const parsed = JSON.parse(contentStr);
          const vendors = parsed.vendors || [];

          return { vendors };
        } catch (error) {
          console.error("Social vendor search error:", error);
          return { vendors: [] };
        }
      }),

    chat: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        message: z.string(),
      }))
      .mutation(async ({ input }) => {
        await saveChatMessage({
          eventId: input.eventId,
          role: "user",
          content: input.message,
        });

        const history = await getChatMessagesByEvent(input.eventId);
        const messages = history.map(msg => ({
          role: msg.role as "user" | "assistant",
          content: msg.content as string,
        }));

        const systemPrompt = `You are PartyWise AI, an expert party planning assistant. Help users plan their perfect party by:
- Providing timeline suggestions and next steps
- Offering budget advice and cost-saving tips
- Recommending vendor types they might have missed
- Suggesting party themes and decoration ideas
- Answering questions about party planning logistics

Be friendly, enthusiastic, and practical. Keep responses concise but helpful.`;

        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: systemPrompt },
              ...messages,
            ],
          });

          const content = response.choices[0]?.message?.content;
          const assistantMessage = typeof content === 'string' ? content : "I'm here to help with your party planning!";

          await saveChatMessage({
            eventId: input.eventId,
            role: "assistant",
            content: assistantMessage,
          });

          return { response: assistantMessage };
        } catch (error) {
          console.error("Chat error:", error);
          return { response: "I'm having trouble right now, but I'm here to help! Could you try asking again?" };
        }
      }),
  }),

  guests: router({
    add: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        name: z.string(),
        email: z.string().email().optional(),
        phone: z.string().optional(),
        plusOne: z.boolean().optional(),
        dietaryRestrictions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await addGuest({
          eventId: input.eventId,
          name: input.name,
          email: input.email,
          phone: input.phone,
          plusOne: input.plusOne,
          dietaryRestrictions: input.dietaryRestrictions,
        });
        return { guestId: Number(result.insertId) };
      }),

    list: protectedProcedure
      .input(z.object({
        eventId: z.number(),
      }))
      .query(async ({ input }) => {
        const guestList = await getGuestsByEvent(input.eventId);
        return { guests: guestList };
      }),

    updateRSVP: protectedProcedure
      .input(z.object({
        guestId: z.number(),
        status: z.enum(["pending", "attending", "declined"]),
      }))
      .mutation(async ({ input }) => {
        await updateGuestRSVP(input.guestId, input.status);
        return { success: true };
      }),

    sendInvite: protectedProcedure
      .input(z.object({
        guestId: z.number(),
        eventName: z.string(),
        eventDate: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await markInviteSent(input.guestId);
        return { success: true, message: "Invite sent successfully!" };
      }),

    delete: protectedProcedure
      .input(z.object({
        guestId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await deleteGuest(input.guestId);
        return { success: true };
      }),
  }),

  budget: router({
    list: protectedProcedure
      .input(z.object({
        eventId: z.number(),
      }))
      .query(async ({ input }) => {
        const items = await getBudgetItems(input.eventId);
        return { items };
      }),

    addItem: protectedProcedure
      .input(z.object({
        eventId: z.number(),
        category: z.string(),
        itemName: z.string(),
        estimatedCost: z.number(),
        actualCost: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await addBudgetItem({
          eventId: input.eventId,
          category: input.category,
          itemName: input.itemName,
          estimatedCost: input.estimatedCost,
          actualCost: input.actualCost,
          notes: input.notes,
        });
        return { itemId: Number(result.insertId) };
      }),

    togglePaid: protectedProcedure
      .input(z.object({
        itemId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await toggleBudgetItemPaid(input.itemId);
        return { success: true };
      }),

    deleteItem: protectedProcedure
      .input(z.object({
        itemId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await deleteBudgetItem(input.itemId);
        return { success: true };
      }),
  }),

  share: router({
    generateShareData: protectedProcedure
      .input(
        z.object({
          eventId: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const events = await getUserPartyEvents(ctx.user.id);
        const event = events.find((e) => e.id === input.eventId);
        
        if (!event) {
          return {
            success: false,
            shareText: "",
            eventName: "",
            eventDate: null,
            guestCount: null,
            budget: null,
          };
        }

        const shareText = `🎉 Planning my ${event.eventName}! 🎊\n\nDate: ${event.eventDate ? new Date(event.eventDate).toLocaleDateString() : 'TBD'}\nGuests: ${event.guestCount || 'TBD'}\nBudget: $${event.budget?.toLocaleString() || 'TBD'}\n\nPlanned with PartyWise ✨`;
        
        return {
          success: true,
          shareText,
          eventName: event.eventName,
          eventDate: event.eventDate,
          guestCount: event.guestCount,
          budget: event.budget,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
