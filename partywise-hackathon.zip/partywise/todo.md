# PartyWise TODO

## Core Features
- [x] Zipcode-based venue search and comparison
- [x] Caterer search and price comparison
- [x] Photographer search and price comparison
- [x] Social media integration (Instagram/Facebook) for small vendors (bakers, florists)
- [x] Amazon product search with best value and best price ranking
- [x] AI-powered party planning guidance and next steps
- [x] Elegant party-themed UI/UX design
- [x] Accessible interface design

## Database Schema
- [x] Party events table
- [x] Vendor results table
- [x] Search history table
- [x] User preferences table

## Backend Implementation
- [x] tRPC procedures for vendor search
- [x] AI agent integration for party planning
- [x] External API integrations (social media, Amazon)
- [x] Price comparison logic

## Frontend Implementation
- [x] Landing page with zipcode input
- [x] Vendor comparison dashboard
- [x] Results filtering and sorting
- [x] AI chat interface for party planning
- [x] Responsive design for mobile

## New Updates
- [x] Embed Digital Ocean AI chatbot widget
- [x] Update color scheme to dark purple and navy blue theme
- [x] Update chatbot widget colors to match new theme

## UI/UX Improvements & New Features
- [x] Redesign navigation for better usability
- [x] Add creative visual elements and animations
- [x] Improve overall user flow and accessibility
- [x] Create dedicated social media vendor comparison page
- [x] Build Instagram/Facebook vendor discovery interface
- [x] Create guest list management page
- [x] Implement invite sending system
- [x] Add guest RSVP tracking

## Additional Pages & Navigation
- [x] Budget Tracker page with visual progress bars
- [x] Timeline/Checklist page with AI-powered milestones
- [x] Vendor Booking Calendar page with availability checking
- [x] Top navigation bar across all pages
- [x] GitHub repository setup and code push

## Bug Fixes & Design Updates
- [x] Fix AI chatbot not appearing/working
- [x] Resolve GitHub push authentication issues (manual upload instructions provided)
- [x] Redesign UI with navy blue background
- [x] Update color scheme to pink and blue accents
- [x] Add playful, fun party aesthetic matching screenshot
- [x] Update typography to match casual, friendly vibe (Pacifico + Poppins)
- [x] Add decorative elements (flowers, party emojis, animations)

## Final Enhancements
- [x] Change background from navy to electric purple
- [x] Add more animations throughout the site
- [x] Party Themes preset feature (Birthday, Wedding, Corporate)
- [x] Social sharing with generated party text
- [ ] Demo video/GIF for GitHub README (optional)

## Bug Fixes
- [x] Fix nested anchor tag error in Navigation component

## New Requirements
- [x] Remove Digital Ocean chatbot widget
- [x] Verify built-in AI assistant works in planner (already implemented in Planner.tsx)
- [x] Change all blue accent colors to purple

## Critical Bug Fixes
- [x] Fix Find Vendors tab - not functioning properly
